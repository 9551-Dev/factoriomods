require("prototypes/torch")
require("prototypes/smolderingtorch")
require("prototypes/deadtorch")