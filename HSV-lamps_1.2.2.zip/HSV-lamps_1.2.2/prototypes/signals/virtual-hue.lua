data:extend({
    {
        type="virtual-signal",
        localised_name="[HSV lamps] HUE",
        name="hsv-hue",
        icon="__HSV-lamps__/graphics/signals/hue.png",
        icon_size=32
    }
})