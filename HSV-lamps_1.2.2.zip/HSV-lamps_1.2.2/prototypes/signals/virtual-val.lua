data:extend({
    {
        type="virtual-signal",
        localised_name="[HSV lamps] VALUE",
        name="hsv-val",
        icon="__HSV-lamps__/graphics/signals/val.png",
        icon_size=32
    }
})