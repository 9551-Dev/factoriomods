return {
    H={
        type="virtual",
        name="hsv-hue"
    },
    S={
        type="virtual",
        name="hsv-sat"
    },
    V={
        type="virtual",
        name="hsv-val"
    },
}