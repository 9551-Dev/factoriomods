data:extend({
    {
        type="item",
        name="uranium-inserter-item",
        icon="__uranium-toolkit__/graphics/icons/inserter.png",
        icon_size=64,
        stack_size=50,
        subgroup="inserter",
        order = "f[stack-inserter]-z[uranium-inserter]",
        place_result="uranium-inserter"
    }
})