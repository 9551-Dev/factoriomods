data:extend({
    {
        type="item",
        name="uranium-underground-belt-item",
        icon="__uranium-toolkit__/graphics/icons/underground.png",
        icon_size=32,
        stack_size=50,
        subgroup="belt",
        order = "b[underground-belt]-z[uranium-underground-belt]",
        place_result="uranium-underground-belt"
    }
})