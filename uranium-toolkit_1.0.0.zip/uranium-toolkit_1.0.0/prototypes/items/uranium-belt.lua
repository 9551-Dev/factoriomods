data:extend({
    {
        type="item",
        name="uranium-belt-item",
        icon="__uranium-toolkit__/graphics/icons/belt.png",
        icon_size=32,
        stack_size=100,
        subgroup="belt",
        order = "a[transport-belt]-z[uranium-transport-belt]",
        place_result="uranium-belt"
    }
})