data:extend({
    {
        type="item",
        name="uranium-splitter-item",
        icon="__uranium-toolkit__/graphics/icons/splitter.png",
        icon_size=32,
        stack_size=50,
        subgroup="belt",
        order = "c[splitter]-z[uranium-splitter]",
        place_result="uranium-splitter"
    }
})