require("__uranium-toolkit__/prototypes/entities/uranium-belt")
require("__uranium-toolkit__/prototypes/entities/uranium-underground")
require("__uranium-toolkit__/prototypes/entities/uranium-splitter")
require("__uranium-toolkit__/prototypes/entities/uranium-inserter")