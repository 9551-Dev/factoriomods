require("__uranium-toolkit__/prototypes/corpses/uranium-belt.lua")
require("__uranium-toolkit__/prototypes/items/uranium-belt.lua")
require("__uranium-toolkit__/prototypes/recipes/uranium-belt.lua")

require("__uranium-toolkit__/prototypes/corpses/uranium-underground.lua")
require("__uranium-toolkit__/prototypes/items/uranium-underground.lua")
require("__uranium-toolkit__/prototypes/recipes/uranium-underground.lua")

require("__uranium-toolkit__/prototypes/corpses/uranium-splitter.lua")
require("__uranium-toolkit__/prototypes/items/uranium-splitter.lua")
require("__uranium-toolkit__/prototypes/recipes/uranium-splitter.lua")

require("__uranium-toolkit__/prototypes/corpses/uranium-inserter.lua")
require("__uranium-toolkit__/prototypes/items/uranium-inserter.lua")
require("__uranium-toolkit__/prototypes/recipes/uranium-inserter.lua")

require("__uranium-toolkit__/research/science.lua")