data.raw["transport-belt"]["express-transport-belt"].next_upgrade = "uranium-belt"
data.raw["underground-belt"]["express-underground-belt"].next_upgrade = "uranium-underground-belt"
data.raw["splitter"]["express-splitter"].next_upgrade = "uranium-splitter"
data.raw["inserter"]["stack-inserter"].next_upgrade = "uranium-inserter"