data:extend({
    {
        type="virtual-signal",
        localised_name="[HSV lamps] SATURATION",
        name="hsv-sat",
        icon="__HSV-lamps__/graphics/signals/sat.png",
        icon_size=32
    }
})