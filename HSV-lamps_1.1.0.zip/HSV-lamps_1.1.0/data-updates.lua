require("__HSV-lamps__/prototypes/science/research.lua")

require("__HSV-lamps__/prototypes/lamps/small-hsv-lamp.lua")
require("__HSV-lamps__/prototypes/lamps/flat-lamp/small-flat-hsv-lamp.lua")