for i=1,6 do
    data:extend({
        {
            type="sound",
            name="TC:chop_"..i,
            filename="__trupen-chops__/sound/chop_"..i..".ogg"
        }
    })
end