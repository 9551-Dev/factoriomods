data:extend({
    {
        type = "int-setting",
        name = "cabrangemult",
        setting_type = "startup",
        default_value = 2,
        minimum_value = 1,
        maximum_value = 5
    },
    {
        type = "int-setting",
        name = "robrangemult",
        setting_type = "startup",
        default_value = 2,
        minimum_value = 1,
        maximum_value = 5
    }
})