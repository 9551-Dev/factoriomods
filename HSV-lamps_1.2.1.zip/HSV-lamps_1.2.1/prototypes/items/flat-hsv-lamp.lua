data:extend({
    {
        type="item",
        name="small-flat-hsv-lamp-item",
        stack_size=50,
        icon="__HSV-lamps__/graphics/icons/hsv-flat-lamp-icon.png",
        icon_size=32,
        place_result="small-flat-hsv-lamp",
        localised_name="HSV lamp",
        localised_description="a colorful lamp with HSV support"
    }
})